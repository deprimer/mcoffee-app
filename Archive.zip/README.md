# MCoffee - Personal Coffee Logger

A mobile application for iOS that allows you to meticulously log your daily coffee brewing process. Track key variables like bean type, grind settings, water parameters, and brew time, along with subjective taste assessments to improve your coffee brewing skills over time.

## Features

- **Comprehensive Logging**: Record essential parameters (coffee type, weight, water, grind) and optional details (temperature, brew method, origin, roast level)
- **Taste Assessment**: Rate your brews and add detailed tasting notes to track your coffee journey
- **Smart Suggestions**: Get intelligent recommendations for grind settings based on your past successful brews
- **Intuitive History**: View, search, and filter your brewing history with detailed information
- **Native iOS Experience**: Clean, intuitive interface following Apple's Human Interface Guidelines
- **Local Storage**: All your data stays on your device with reliable local persistence
- **Streamlined Entry**: Quick and efficient logging process for your daily coffee routine

## Technology

- Kotlin Multiplatform (KMP) for shared business logic
- Swift/SwiftUI for native iOS UI components
- Local data persistence

## Getting Started

1. Clone this repository
2. Open the project in Xcode or Android Studio
3. Build and run on your iOS device or simulator

## Project Structure

- `shared/` - Contains shared Kotlin code for data models and business logic
- `iosApp/` - Contains iOS-specific code and UI implementation
