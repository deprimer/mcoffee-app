package com.mcoffee.database

import com.squareup.sqldelight.db.SqlDriver
import com.squareup.sqldelight.drivers.native.NativeSqliteDriver
import com.mcoffee.database.MCoffeeDatabase

/**
 * iOS implementation of the database driver factory
 */
actual class DatabaseDriverFactory {
    actual fun createDriver(): SqlDriver {
        return NativeSqliteDriver(MCoffeeDatabase.Schema, "mcoffee.db")
    }
}
