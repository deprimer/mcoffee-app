package com.mcoffee.database

import com.squareup.sqldelight.db.SqlDriver

/**
 * Platform-specific database driver factory
 */
expect class DatabaseDriverFactory {
    fun createDriver(): SqlDriver
}
