package com.mcoffee.viewmodel

import com.mcoffee.model.BrewLog
import com.mcoffee.model.BrewMethod
import com.mcoffee.model.RoastLevel
import com.mcoffee.model.TemperatureUnit
import com.mcoffee.repository.BrewLogRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.datetime.Clock
import kotlinx.datetime.Instant
import kotlinx.datetime.TimeZone
import kotlinx.datetime.toLocalDateTime
import kotlin.random.Random

/**
 * ViewModel for managing brew log data and business logic
 */
class BrewLogViewModel(private val repository: BrewLogRepository) {
    
    // UI state for creating a new brew log
    private val _newBrewLogState = MutableStateFlow(NewBrewLogState())
    val newBrewLogState: StateFlow<NewBrewLogState> = _newBrewLogState.asStateFlow()
    
    // UI state for viewing brew logs
    private val _brewLogsState = MutableStateFlow<BrewLogsState>(BrewLogsState.Loading)
    val brewLogsState: StateFlow<BrewLogsState> = _brewLogsState.asStateFlow()
    
    // UI state for grind setting suggestions
    private val _suggestionState = MutableStateFlow<SuggestionState>(SuggestionState.NoSuggestion)
    val suggestionState: StateFlow<SuggestionState> = _suggestionState.asStateFlow()
    
    // Get all brew logs as a flow for reactive updates
    val brewLogsFlow: Flow<List<BrewLog>> = repository.getBrewLogsAsFlow()
    
    // Load all brew logs
    suspend fun loadBrewLogs() {
        try {
            _brewLogsState.value = BrewLogsState.Loading
            val brewLogs = repository.getAllBrewLogs()
            _brewLogsState.value = BrewLogsState.Success(brewLogs)
        } catch (e: Exception) {
            _brewLogsState.value = BrewLogsState.Error(e.message ?: "Unknown error")
        }
    }
    
    // Get a brew log by ID
    suspend fun getBrewLogById(logId: String): BrewLog? {
        return repository.getBrewLogById(logId)
    }
    
    // Update new brew log state
    fun updateNewBrewLogState(update: (NewBrewLogState) -> NewBrewLogState) {
        _newBrewLogState.value = update(_newBrewLogState.value)
    }
    
    // Save a new brew log
    suspend fun saveBrewLog() {
        val state = _newBrewLogState.value
        
        // Validate required fields
        if (state.coffeeType.isBlank() || 
            state.coffeeGrams <= 0 || 
            state.waterGrams <= 0 || 
            state.grindSetting.isBlank()) {
            _newBrewLogState.value = state.copy(error = "Please fill in all required fields")
            return
        }
        
        // Calculate ratio if not already set
        val ratio = state.ratio ?: (state.waterGrams / state.coffeeGrams)
        
        // Create a new brew log
        val brewLog = BrewLog(
            logId = generateUniqueId(),
            timestamp = Clock.System.now(),
            coffeeType = state.coffeeType,
            coffeeGrams = state.coffeeGrams,
            waterGrams = state.waterGrams,
            grindSetting = state.grindSetting,
            waterTemperature = state.waterTemperature,
            temperatureUnit = state.temperatureUnit,
            brewMethod = state.brewMethod,
            beanOrigin = state.beanOrigin,
            roastLevel = state.roastLevel,
            brewTimeSeconds = state.brewTimeSeconds,
            tasteRating = state.tasteRating,
            tasteNotes = state.tasteNotes,
            photoPath = state.photoPath,
            ratio = ratio
        )
        
        // Save the brew log
        repository.saveBrewLog(brewLog)
        
        // Reset the state
        _newBrewLogState.value = NewBrewLogState()
        _suggestionState.value = SuggestionState.NoSuggestion
    }
    
    // Delete a brew log
    suspend fun deleteBrewLog(logId: String) {
        repository.deleteBrewLog(logId)
        loadBrewLogs()
    }
    
    // Get brew logs by coffee type
    suspend fun getBrewLogsByCoffeeType(coffeeType: String): List<BrewLog> {
        return repository.getBrewLogsByCoffeeType(coffeeType)
    }
    
    // Get brew logs by brew method
    suspend fun getBrewLogsByBrewMethod(brewMethod: BrewMethod): List<BrewLog> {
        return repository.getBrewLogsByBrewMethod(brewMethod)
    }
    
    // Get brew logs by minimum rating
    suspend fun getBrewLogsByMinimumRating(minRating: Int): List<BrewLog> {
        return repository.getBrewLogsByMinimumRating(minRating)
    }
    
    // Get brew logs by date range
    suspend fun getBrewLogsByDateRange(startDate: Instant, endDate: Instant): List<BrewLog> {
        return repository.getBrewLogsByDateRange(startDate, endDate)
    }
    
    // Get suggested grind setting based on previous brews
    suspend fun getSuggestedGrindSetting() {
        val state = _newBrewLogState.value
        
        // We need both coffee type and brew method to make a suggestion
        if (state.coffeeType.isBlank() || state.brewMethod == null) {
            _suggestionState.value = SuggestionState.NoSuggestion
            return
        }
        
        try {
            _suggestionState.value = SuggestionState.Loading
            
            // Get previous logs with the same coffee type and brew method
            val previousLogs = repository.getBrewLogsByCoffeeTypeAndBrewMethod(
                state.coffeeType, state.brewMethod
            )
            
            if (previousLogs.isEmpty()) {
                _suggestionState.value = SuggestionState.NoSuggestion
                return
            }
            
            // Find the log with the highest taste rating
            val bestLog = previousLogs.maxByOrNull { it.tasteRating ?: 0 }
            
            if (bestLog == null || bestLog.tasteRating == null || bestLog.tasteRating < 3) {
                // If no good brews found, look for similar coffee types
                val similarCoffeeTypes = findSimilarCoffeeTypes(state.coffeeType)
                val similarLogs = mutableListOf<BrewLog>()
                
                for (coffeeType in similarCoffeeTypes) {
                    val logs = repository.getBrewLogsByCoffeeTypeAndBrewMethod(
                        coffeeType, state.brewMethod
                    )
                    similarLogs.addAll(logs)
                }
                
                val bestSimilarLog = similarLogs.maxByOrNull { it.tasteRating ?: 0 }
                
                if (bestSimilarLog != null && (bestSimilarLog.tasteRating ?: 0) >= 3) {
                    _suggestionState.value = SuggestionState.Success(
                        SuggestionInfo(
                            grindSetting = bestSimilarLog.grindSetting,
                            sourceCoffeeType = bestSimilarLog.coffeeType,
                            sourceRating = bestSimilarLog.tasteRating ?: 0,
                            isSimilarCoffee = true
                        )
                    )
                } else {
                    // If no good similar brews found, suggest a general recommendation
                    suggestGeneralGrindSetting(state.brewMethod)
                }
            } else {
                // We found a good previous brew, use its grind setting
                _suggestionState.value = SuggestionState.Success(
                    SuggestionInfo(
                        grindSetting = bestLog.grindSetting,
                        sourceCoffeeType = bestLog.coffeeType,
                        sourceRating = bestLog.tasteRating,
                        isSimilarCoffee = false
                    )
                )
            }
        } catch (e: Exception) {
            _suggestionState.value = SuggestionState.Error(e.message ?: "Unknown error")
        }
    }
    
    // Find similar coffee types based on keywords
    private fun findSimilarCoffeeTypes(coffeeType: String): List<String> {
        // Extract potential origin or key descriptors from the coffee type
        val keywords = coffeeType.split(" ").filter { it.length > 3 }
        
        // Get all coffee types from the repository
        val allCoffeeTypes = brewLogsState.value.let {
            when (it) {
                is BrewLogsState.Success -> it.brewLogs.map { log -> log.coffeeType }.distinct()
                else -> emptyList()
            }
        }
        
        // Find coffee types that contain any of the keywords
        return allCoffeeTypes.filter { otherType -> 
            otherType != coffeeType && keywords.any { keyword ->
                otherType.contains(keyword, ignoreCase = true)
            }
        }
    }
    
    // Suggest a general grind setting based on brew method
    private fun suggestGeneralGrindSetting(brewMethod: BrewMethod) {
        val generalSuggestion = when (brewMethod) {
            BrewMethod.ESPRESSO -> "Fine (1-2)"
            BrewMethod.AEROPRESS -> "Medium-Fine (3-4)"
            BrewMethod.POUR_OVER -> "Medium (5-6)"
            BrewMethod.DRIP -> "Medium (5-6)"
            BrewMethod.MOKA_POT -> "Medium-Fine (3-4)"
            BrewMethod.FRENCH_PRESS -> "Coarse (8-9)"
            BrewMethod.COLD_BREW -> "Extra Coarse (10)"
            BrewMethod.SIPHON -> "Medium-Fine (3-4)"
            BrewMethod.CUSTOM -> "Medium (5-6)"
        }
        
        _suggestionState.value = SuggestionState.Success(
            SuggestionInfo(
                grindSetting = generalSuggestion,
                sourceCoffeeType = null,
                sourceRating = null,
                isSimilarCoffee = false,
                isGeneralSuggestion = true
            )
        )
    }
    
    // Calculate coffee to water ratio
    fun calculateRatio(coffeeGrams: Double, waterGrams: Double): Double {
        return if (coffeeGrams > 0) waterGrams / coffeeGrams else 0.0
    }
    
    // Calculate water amount based on coffee and ratio
    fun calculateWater(coffeeGrams: Double, ratio: Double): Double {
        return coffeeGrams * ratio
    }
    
    // Calculate coffee amount based on water and ratio
    fun calculateCoffee(waterGrams: Double, ratio: Double): Double {
        return if (ratio > 0) waterGrams / ratio else 0.0
    }
    
    // Generate a unique ID for a new brew log
    private fun generateUniqueId(): String {
        val timestamp = Clock.System.now().toEpochMilliseconds()
        val random = Random.nextInt(0, 1000)
        return "$timestamp-$random"
    }
}

/**
 * State for creating a new brew log
 */
data class NewBrewLogState(
    val coffeeType: String = "",
    val coffeeGrams: Double = 0.0,
    val waterGrams: Double = 0.0,
    val grindSetting: String = "",
    val waterTemperature: Double? = null,
    val temperatureUnit: TemperatureUnit? = TemperatureUnit.CELSIUS,
    val brewMethod: BrewMethod? = null,
    val beanOrigin: String? = null,
    val roastLevel: RoastLevel? = null,
    val brewTimeSeconds: Int? = null,
    val tasteRating: Int? = null,
    val tasteNotes: String? = null,
    val photoPath: String? = null,
    val ratio: Double? = null,
    val error: String? = null
)

/**
 * State for viewing brew logs
 */
sealed class BrewLogsState {
    object Loading : BrewLogsState()
    data class Success(val brewLogs: List<BrewLog>) : BrewLogsState()
    data class Error(val message: String) : BrewLogsState()
}

/**
 * State for grind setting suggestions
 */
sealed class SuggestionState {
    object NoSuggestion : SuggestionState()
    object Loading : SuggestionState()
    data class Success(val suggestion: SuggestionInfo) : SuggestionState()
    data class Error(val message: String) : SuggestionState()
}

/**
 * Information about a grind setting suggestion
 */
data class SuggestionInfo(
    val grindSetting: String,
    val sourceCoffeeType: String? = null,
    val sourceRating: Int? = null,
    val isSimilarCoffee: Boolean = false,
    val isGeneralSuggestion: Boolean = false
) {
    fun getExplanation(): String {
        return when {
            isGeneralSuggestion -> "Based on your brew method, we recommend a $grindSetting grind."
            isSimilarCoffee && sourceCoffeeType != null -> "Based on your success with $sourceCoffeeType (rated ${sourceRating}/5), we suggest $grindSetting."
            sourceCoffeeType != null -> "Based on your previous brew of this coffee (rated ${sourceRating}/5), we suggest $grindSetting."
            else -> "We suggest $grindSetting for this brew."
        }
    }
}
