package com.mcoffee.model

import kotlinx.datetime.Instant
import kotlinx.serialization.Serializable

/**
 * Represents a coffee brewing log entry
 */
@Serializable
data class BrewLog(
    val logId: String, // Unique identifier
    val timestamp: Instant, // Date and time of logging
    
    // Mandatory fields
    val coffeeType: String, // Type or name of coffee bean/blend
    val coffeeGrams: Double, // Weight of coffee in grams
    val waterGrams: Double, // Weight of water in grams
    val grindSetting: String, // Grinder setting
    
    // Optional fields
    val waterTemperature: Double? = null, // Temperature of water
    val temperatureUnit: TemperatureUnit? = null, // Celsius or Fahrenheit
    val brewMethod: BrewMethod? = null, // Method used for brewing
    val beanOrigin: String? = null, // Geographical origin of beans
    val roastLevel: RoastLevel? = null, // Light, Medium, Dark, etc.
    val brewTimeSeconds: Int? = null, // Total brew time in seconds
    val tasteRating: Int? = null, // Rating (e.g., 1-5 stars)
    val tasteNotes: String? = null, // Subjective taste assessment
    val photoPath: String? = null, // Local path to saved photo
    val ratio: Double? = null // Coffee to water ratio (calculated)
) {
    /**
     * Calculate the coffee to water ratio
     */
    fun calculateRatio(): Double {
        return if (coffeeGrams > 0) waterGrams / coffeeGrams else 0.0
    }
    
    /**
     * Get a display-friendly format of the brew time
     */
    fun getFormattedBrewTime(): String {
        return if (brewTimeSeconds != null && brewTimeSeconds > 0) {
            val minutes = brewTimeSeconds / 60
            val seconds = brewTimeSeconds % 60
            "${minutes}m ${seconds}s"
        } else {
            ""
        }
    }
}

/**
 * Temperature unit options
 */
@Serializable
enum class TemperatureUnit {
    CELSIUS,
    FAHRENHEIT;
    
    fun getSymbol(): String {
        return when (this) {
            CELSIUS -> "°C"
            FAHRENHEIT -> "°F"
        }
    }
}

/**
 * Coffee brewing methods
 */
@Serializable
enum class BrewMethod {
    POUR_OVER,
    AEROPRESS,
    ESPRESSO,
    FRENCH_PRESS,
    MOKA_POT,
    COLD_BREW,
    DRIP,
    SIPHON,
    CUSTOM;
    
    companion object {
        fun fromString(value: String): BrewMethod {
            return values().find { it.name.replace("_", " ").equals(value, ignoreCase = true) }
                ?: CUSTOM
        }
    }
    
    fun getDisplayName(): String {
        return name.replace("_", " ").lowercase().capitalize()
    }
}

/**
 * Coffee roast levels
 */
@Serializable
enum class RoastLevel {
    LIGHT,
    MEDIUM,
    MEDIUM_DARK,
    DARK;
    
    fun getDisplayName(): String {
        return name.replace("_", " ").lowercase().capitalize()
    }
}

/**
 * Extension function to capitalize the first letter of a string
 */
fun String.capitalize(): String {
    return if (this.isNotEmpty()) {
        this[0].uppercase() + this.substring(1)
    } else {
        this
    }
}
