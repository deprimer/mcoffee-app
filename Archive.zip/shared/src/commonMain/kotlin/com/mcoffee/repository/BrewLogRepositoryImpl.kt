package com.mcoffee.repository

import com.mcoffee.database.DatabaseDriverFactory
import com.mcoffee.database.MCoffeeDatabase
import com.mcoffee.model.BrewLog
import com.mcoffee.model.BrewMethod
import com.mcoffee.model.RoastLevel
import com.mcoffee.model.TemperatureUnit
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.datetime.Instant

class BrewLogRepositoryImpl(databaseDriverFactory: DatabaseDriverFactory) : BrewLogRepository {
    private val database = MCoffeeDatabase(databaseDriverFactory.createDriver())
    private val dbQuery = database.brewLogQueries
    
    // Using StateFlow to provide reactive updates
    private val brewLogsFlow = MutableStateFlow<List<BrewLog>>(emptyList())
    
    init {
        // Initialize the flow with all brew logs
        refreshBrewLogs()
    }
    
    private fun refreshBrewLogs() {
        brewLogsFlow.value = dbQuery.getAllBrewLogs().executeAsList().map { it.toBrewLog() }
    }
    
    override suspend fun saveBrewLog(brewLog: BrewLog) {
        dbQuery.insertBrewLog(
            logId = brewLog.logId,
            timestamp = brewLog.timestamp.toEpochMilliseconds(),
            coffeeType = brewLog.coffeeType,
            coffeeGrams = brewLog.coffeeGrams,
            waterGrams = brewLog.waterGrams,
            grindSetting = brewLog.grindSetting,
            waterTemperature = brewLog.waterTemperature,
            temperatureUnit = brewLog.temperatureUnit?.name,
            brewMethod = brewLog.brewMethod?.name,
            beanOrigin = brewLog.beanOrigin,
            roastLevel = brewLog.roastLevel?.name,
            brewTimeSeconds = brewLog.brewTimeSeconds?.toLong(),
            tasteRating = brewLog.tasteRating?.toLong(),
            tasteNotes = brewLog.tasteNotes,
            photoPath = brewLog.photoPath,
            ratio = brewLog.ratio
        )
        refreshBrewLogs()
    }
    
    override suspend fun getBrewLogById(logId: String): BrewLog? {
        return dbQuery.getBrewLogById(logId).executeAsOneOrNull()?.toBrewLog()
    }
    
    override suspend fun getAllBrewLogs(): List<BrewLog> {
        return dbQuery.getAllBrewLogs().executeAsList().map { it.toBrewLog() }
    }
    
    override fun getBrewLogsAsFlow(): Flow<List<BrewLog>> {
        return brewLogsFlow.asStateFlow()
    }
    
    override suspend fun deleteBrewLog(logId: String) {
        dbQuery.deleteBrewLog(logId)
        refreshBrewLogs()
    }
    
    override suspend fun getBrewLogsByCoffeeType(coffeeType: String): List<BrewLog> {
        return dbQuery.getBrewLogsByCoffeeType(coffeeType).executeAsList().map { it.toBrewLog() }
    }
    
    override suspend fun getBrewLogsByBrewMethod(brewMethod: BrewMethod): List<BrewLog> {
        return dbQuery.getBrewLogsByBrewMethod(brewMethod.name).executeAsList().map { it.toBrewLog() }
    }
    
    override suspend fun getBrewLogsByMinimumRating(minRating: Int): List<BrewLog> {
        return dbQuery.getBrewLogsByMinimumRating(minRating.toLong()).executeAsList().map { it.toBrewLog() }
    }
    
    override suspend fun getBrewLogsByDateRange(startDate: Instant, endDate: Instant): List<BrewLog> {
        return dbQuery.getBrewLogsByDateRange(
            startDate.toEpochMilliseconds(),
            endDate.toEpochMilliseconds()
        ).executeAsList().map { it.toBrewLog() }
    }
    
    override suspend fun getBrewLogsByCoffeeTypeAndBrewMethod(coffeeType: String, brewMethod: BrewMethod): List<BrewLog> {
        return dbQuery.getBrewLogsByCoffeeTypeAndBrewMethod(
            coffeeType,
            brewMethod.name
        ).executeAsList().map { it.toBrewLog() }
    }
    
    override suspend fun getBrewLogsByCoffeeTypeAndMinimumRating(coffeeType: String, minRating: Int): List<BrewLog> {
        return dbQuery.getBrewLogsByCoffeeTypeAndMinimumRating(
            coffeeType,
            minRating.toLong()
        ).executeAsList().map { it.toBrewLog() }
    }
    
    override suspend fun getBrewLogsByBrewMethodAndMinimumRating(brewMethod: BrewMethod, minRating: Int): List<BrewLog> {
        return dbQuery.getBrewLogsByBrewMethodAndMinimumRating(
            brewMethod.name,
            minRating.toLong()
        ).executeAsList().map { it.toBrewLog() }
    }
    
    @Deprecated("Use getBrewLogsByCoffeeTypeAndBrewMethod instead", ReplaceWith("getBrewLogsByCoffeeTypeAndBrewMethod(coffeeType, brewMethod)"))
    override suspend fun getSuggestedGrindSetting(coffeeType: String, brewMethod: BrewMethod): String? {
        // Get previous logs with the same coffee type and brew method
        val previousLogs = getBrewLogsByCoffeeTypeAndBrewMethod(coffeeType, brewMethod)
        
        if (previousLogs.isEmpty()) {
            return null
        }
        
        // Find the log with the highest taste rating
        val bestLog = previousLogs.maxByOrNull { it.tasteRating ?: 0 }
        
        return bestLog?.grindSetting
    }
    
    // Extension function to convert database entity to domain model
    private fun com.mcoffee.database.BrewLog.toBrewLog(): BrewLog {
        return BrewLog(
            logId = logId,
            timestamp = Instant.fromEpochMilliseconds(timestamp),
            coffeeType = coffeeType,
            coffeeGrams = coffeeGrams,
            waterGrams = waterGrams,
            grindSetting = grindSetting,
            waterTemperature = waterTemperature,
            temperatureUnit = temperatureUnit?.let { TemperatureUnit.valueOf(it) },
            brewMethod = brewMethod?.let { BrewMethod.valueOf(it) },
            beanOrigin = beanOrigin,
            roastLevel = roastLevel?.let { RoastLevel.valueOf(it) },
            brewTimeSeconds = brewTimeSeconds?.toInt(),
            tasteRating = tasteRating?.toInt(),
            tasteNotes = tasteNotes,
            photoPath = photoPath,
            ratio = ratio
        )
    }
}
