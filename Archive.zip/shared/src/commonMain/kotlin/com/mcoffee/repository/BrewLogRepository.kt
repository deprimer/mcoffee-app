package com.mcoffee.repository

import com.mcoffee.model.BrewLog
import com.mcoffee.model.BrewMethod
import com.mcoffee.model.RoastLevel
import com.mcoffee.model.TemperatureUnit
import kotlinx.coroutines.flow.Flow
import kotlinx.datetime.Instant

/**
 * Repository interface for managing BrewLog data
 */
interface BrewLogRepository {
    /**
     * Save a new brew log entry
     */
    suspend fun saveBrewLog(brewLog: BrewLog)
    
    /**
     * Get a brew log by its ID
     */
    suspend fun getBrewLogById(logId: String): BrewLog?
    
    /**
     * Get all brew logs
     */
    suspend fun getAllBrewLogs(): List<BrewLog>
    
    /**
     * Get brew logs as a Flow for reactive updates
     */
    fun getBrewLogsAsFlow(): Flow<List<BrewLog>>
    
    /**
     * Delete a brew log
     */
    suspend fun deleteBrewLog(logId: String)
    
    /**
     * Get brew logs filtered by coffee type
     */
    suspend fun getBrewLogsByCoffeeType(coffeeType: String): List<BrewLog>
    
    /**
     * Get brew logs filtered by brew method
     */
    suspend fun getBrewLogsByBrewMethod(brewMethod: BrewMethod): List<BrewLog>
    
    /**
     * Get brew logs with rating greater than or equal to the specified value
     */
    suspend fun getBrewLogsByMinimumRating(minRating: Int): List<BrewLog>
    
    /**
     * Get brew logs within a date range
     */
    suspend fun getBrewLogsByDateRange(startDate: Instant, endDate: Instant): List<BrewLog>
    
    /**
     * Get brew logs by coffee type and brew method
     */
    suspend fun getBrewLogsByCoffeeTypeAndBrewMethod(coffeeType: String, brewMethod: BrewMethod): List<BrewLog>
    
    /**
     * Get brew logs by coffee type and minimum rating
     */
    suspend fun getBrewLogsByCoffeeTypeAndMinimumRating(coffeeType: String, minRating: Int): List<BrewLog>
    
    /**
     * Get brew logs by brew method and minimum rating
     */
    suspend fun getBrewLogsByBrewMethodAndMinimumRating(brewMethod: BrewMethod, minRating: Int): List<BrewLog>
    
    /**
     * Get suggested grind setting based on previous logs with the same coffee type and brew method
     * @deprecated Use getBrewLogsByCoffeeTypeAndBrewMethod instead and implement suggestion logic in the ViewModel
     */
    @Deprecated("Use getBrewLogsByCoffeeTypeAndBrewMethod instead", ReplaceWith("getBrewLogsByCoffeeTypeAndBrewMethod(coffeeType, brewMethod)"))
    suspend fun getSuggestedGrindSetting(coffeeType: String, brewMethod: BrewMethod): String?
}
