package com.mcoffee.database

import com.squareup.sqldelight.db.SqlDriver
import com.squareup.sqldelight.sqlite.driver.JdbcSqliteDriver
import java.io.File

/**
 * JVM implementation of the database driver factory
 */
actual class DatabaseDriverFactory {
    actual fun createDriver(): SqlDriver {
        val databasePath = File(System.getProperty("user.home"), "mcoffee.db")
        val driver = JdbcSqliteDriver("jdbc:sqlite:${databasePath.absolutePath}")
        
        // Create the database if it doesn't exist
        if (!databasePath.exists()) {
            MCoffeeDatabase.Schema.create(driver)
        }
        
        return driver
    }
}
