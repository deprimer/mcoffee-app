plugins {
    kotlin("multiplatform")
    kotlin("native.cocoapods")
    kotlin("plugin.serialization")
    id("com.squareup.sqldelight")
}

group = "com.mcoffee"
version = "1.0"

kotlin {
    jvm()
    
    // Configure iOS targets
    listOf(
        iosX64(),
        iosArm64(),
        iosSimulatorArm64() // Add support for Apple Silicon simulators
    ).forEach {
        it.binaries.framework {
            baseName = "shared"
            isStatic = false
        }
    }
    
    cocoapods {
        summary = "MCoffee shared module"
        homepage = "https://github.com/yourusername/mcoffee"
        ios.deploymentTarget = "14.0"
        podfile = project.file("../Podfile")
    }
    
    sourceSets {
        val commonMain by getting {
            dependencies {
                // SQLDelight for database
                implementation("com.squareup.sqldelight:runtime:1.5.5")
                // Kotlinx serialization
                implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.5.1")
                // Kotlinx datetime
                implementation("org.jetbrains.kotlinx:kotlinx-datetime:0.4.0")
                // Coroutines
                implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.7.3")
            }
        }
        
        val commonTest by getting {
            dependencies {
                implementation(kotlin("test"))
            }
        }
        
        val jvmMain by getting {
            dependencies {
                implementation("com.squareup.sqldelight:sqlite-driver:1.5.5")
            }
        }
        val jvmTest by getting
        
        // Create a common iOS source set
        val iosMain by creating {
            dependsOn(commonMain)
            dependencies {
                implementation("com.squareup.sqldelight:native-driver:1.5.5")
            }
        }
        val iosTest by creating {
            dependsOn(commonTest)
        }
        
        // Link the iOS source sets to their respective targets
        val iosX64Main by getting {
            dependsOn(iosMain)
        }
        val iosArm64Main by getting {
            dependsOn(iosMain)
        }
        val iosSimulatorArm64Main by getting {
            dependsOn(iosMain)
        }
        val iosX64Test by getting {
            dependsOn(iosTest)
        }
        val iosArm64Test by getting {
            dependsOn(iosTest)
        }
        val iosSimulatorArm64Test by getting {
            dependsOn(iosTest)
        }
    }
}

sqldelight {
    database("MCoffeeDatabase") {
        packageName = "com.mcoffee.database"
        sourceFolders = listOf("sqldelight")
    }
}
