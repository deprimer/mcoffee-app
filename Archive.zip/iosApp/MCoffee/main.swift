import UIKit

// This file serves as the app's entry point instead of using @main attribute
UIApplicationMain(
    CommandLine.argc,
    CommandLine.unsafeArgv,
    nil,
    NSStringFromClass(AppDelegate.self)
)
