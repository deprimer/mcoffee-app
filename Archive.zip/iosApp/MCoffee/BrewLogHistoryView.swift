import SwiftUI
import shared
import Foundation

// Mock data for the brew log history view
struct MockBrewLog: Identifiable {
    let id: String
    let timestamp: Date
    let coffeeType: String
    let coffeeGrams: Double
    let waterGrams: Double
    let grindSetting: String
    let waterTemperature: Double?
    let temperatureUnit: String?
    let brewMethod: String?
    let beanOrigin: String?
    let roastLevel: String?
    let brewTimeSeconds: Int?
    let tasteRating: Int?
    let tasteNotes: String?
    let photoPath: String?
    let ratio: Double?
}

// Display item for the brew log history view
struct BrewLogDisplayItem: Identifiable {
    let id: String
    let coffeeType: String
    let coffeeGrams: Double
    let waterGrams: Double
    let grindSetting: String
    let brewMethod: String?
    let beanOrigin: String?
    let tasteRating: Int?
    let tasteNotes: String?
    let timestamp: Date
    let originalLog: MockBrewLog
    
    var ratio: Double {
        return waterGrams / coffeeGrams
    }
    
    var formattedDate: String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter.string(from: timestamp)
    }
}

struct BrewLogHistoryView: View {
    @State private var brewLogs: [BrewLogDisplayItem] = []
    @State private var isLoading = true
    @State private var searchText = ""
    @State private var sortOption = 0 // 0 = Date (newest), 1 = Rating (highest), 2 = Coffee Type
    @State private var filterBrewMethod: Int? = nil
    @State private var showFilterSheet = false
    @State private var isPresentingSheet = false // Use this instead of presentationDetents
    
    // Sample brew methods for filtering
    let brewMethods = ["All", "Pour Over", "Aeropress", "Espresso", "French Press", "Moka Pot", "Cold Brew", "Drip", "Siphon"]
    
    // Sample data for the brew log history view
    let sampleBrewLogs: [BrewLogDisplayItem] = [
        BrewLogDisplayItem(
            id: "1",
            coffeeType: "Ethiopian Yirgacheffe",
            coffeeGrams: 18.0,
            waterGrams: 300.0,
            grindSetting: "Medium-Fine (15)",
            brewMethod: "Pour Over",
            beanOrigin: "Ethiopia",
            tasteRating: 4,
            tasteNotes: "Bright acidity, floral notes with hints of citrus. Very clean finish.",
            timestamp: Date().addingTimeInterval(-86400), // Yesterday
            originalLog: MockBrewLog(
                id: "1",
                timestamp: Date().addingTimeInterval(-86400),
                coffeeType: "Ethiopian Yirgacheffe",
                coffeeGrams: 18.0,
                waterGrams: 300.0,
                grindSetting: "Medium-Fine (15)",
                waterTemperature: 94.0,
                temperatureUnit: "C",
                brewMethod: "Pour Over",
                beanOrigin: "Ethiopia",
                roastLevel: "Light",
                brewTimeSeconds: 180,
                tasteRating: 4,
                tasteNotes: "Bright acidity, floral notes with hints of citrus. Very clean finish.",
                photoPath: nil,
                ratio: 16.67
            )
        ),
        BrewLogDisplayItem(
            id: "2",
            coffeeType: "Colombian Supremo",
            coffeeGrams: 20.0,
            waterGrams: 320.0,
            grindSetting: "Medium (20)",
            brewMethod: "French Press",
            beanOrigin: "Colombia",
            tasteRating: 5,
            tasteNotes: "Rich body with chocolate and caramel notes. Smooth finish.",
            timestamp: Date().addingTimeInterval(-172800), // 2 days ago
            originalLog: MockBrewLog(
                id: "2",
                timestamp: Date().addingTimeInterval(-172800),
                coffeeType: "Colombian Supremo",
                coffeeGrams: 20.0,
                waterGrams: 320.0,
                grindSetting: "Medium (20)",
                waterTemperature: 92.0,
                temperatureUnit: "C",
                brewMethod: "French Press",
                beanOrigin: "Colombia",
                roastLevel: "Medium",
                brewTimeSeconds: 240,
                tasteRating: 5,
                tasteNotes: "Rich body with chocolate and caramel notes. Smooth finish.",
                photoPath: nil,
                ratio: 16.0
            )
        ),
        BrewLogDisplayItem(
            id: "3",
            coffeeType: "Sumatra Mandheling",
            coffeeGrams: 16.0,
            waterGrams: 250.0,
            grindSetting: "Fine (10)",
            brewMethod: "Aeropress",
            beanOrigin: "Indonesia",
            tasteRating: 3,
            tasteNotes: "Earthy with herbal notes. A bit too bitter, might try coarser grind next time.",
            timestamp: Date().addingTimeInterval(-259200), // 3 days ago
            originalLog: MockBrewLog(
                id: "3",
                timestamp: Date().addingTimeInterval(-259200),
                coffeeType: "Sumatra Mandheling",
                coffeeGrams: 16.0,
                waterGrams: 250.0,
                grindSetting: "Fine (10)",
                waterTemperature: 85.0,
                temperatureUnit: "C",
                brewMethod: "Aeropress",
                beanOrigin: "Indonesia",
                roastLevel: "Dark",
                brewTimeSeconds: 90,
                tasteRating: 3,
                tasteNotes: "Earthy with herbal notes. A bit too bitter, might try coarser grind next time.",
                photoPath: nil,
                ratio: 15.625
            )
        )
    ]
    
    var body: some View {
        VStack {
            // Search and filter bar
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(.gray)
                TextField("Search", text: $searchText)
                
                Button(action: {
                    showFilterSheet = true
                }) {
                    Image(systemName: "line.3.horizontal.decrease.circle")
                        .foregroundColor(.blue)
                }
            }
            .padding(.horizontal)
            .padding(.vertical, 8)
            .background(Color(.systemGray6))
            .cornerRadius(10)
            .padding(.horizontal)
            
            if isLoading {
                ProgressView("Loading brew logs...")
                    .padding()
                Spacer()
            } else if brewLogs.isEmpty {
                VStack {
                    Spacer()
                    Text("No brew logs found")
                        .font(.headline)
                    Text("Start brewing and logging your coffee!")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                    Spacer()
                }
            } else {
                List {
                    ForEach(filteredAndSortedLogs) { brewLog in
                        NavigationLink(destination: BrewLogDetailView(brewLog: brewLog.originalLog)) {
                            BrewLogRowView(brewLog: brewLog)
                        }
                    }
                    .onDelete(perform: deleteBrewLog)
                }
                .listStyle(InsetGroupedListStyle())
            }
        }
        .navigationTitle("Brew History")
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Menu {
                    Picker("Sort By", selection: $sortOption) {
                        Text("Date (Newest)").tag(0)
                        Text("Rating (Highest)").tag(1)
                        Text("Coffee Type").tag(2)
                    }
                } label: {
                    Label("Sort", systemImage: "arrow.up.arrow.down")
                }
            }
        }
        .sheet(isPresented: $showFilterSheet) {
            FilterView(
                selectedBrewMethod: $filterBrewMethod,
                brewMethods: brewMethods,
                isPresented: $showFilterSheet
            )
            // Removed presentationDetents for iOS 14 compatibility
        }
        .onAppear {
            loadBrewLogs()
        }
    }
    
    // Filter and sort logs based on user selections
    private var filteredAndSortedLogs: [BrewLogDisplayItem] {
        var result = brewLogs
        
        // Apply search filter
        if !searchText.isEmpty {
            result = result.filter { log in
                log.coffeeType.localizedCaseInsensitiveContains(searchText) ||
                (log.beanOrigin?.localizedCaseInsensitiveContains(searchText) ?? false) ||
                (log.tasteNotes?.localizedCaseInsensitiveContains(searchText) ?? false)
            }
        }
        
        // Apply brew method filter
        if let filterMethod = filterBrewMethod, filterMethod > 0 {
            result = result.filter { log in
                log.brewMethod == brewMethods[filterMethod]
            }
        }
        
        // Apply sorting
        switch sortOption {
        case 0: // Date (newest first)
            result.sort { $0.timestamp > $1.timestamp }
        case 1: // Rating (highest first)
            result.sort { ($0.tasteRating ?? 0) > ($1.tasteRating ?? 0) }
        case 2: // Coffee Type (alphabetical)
            result.sort { $0.coffeeType < $1.coffeeType }
        default:
            break
        }
        
        return result
    }
    
    // Load brew logs from repository
    private func loadBrewLogs() {
        isLoading = true
        
        // In a real implementation, this would load from the Kotlin ViewModel
        // For demo purposes, we'll load sample data
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            self.brewLogs = sampleBrewLogs
            self.isLoading = false
        }
    }
    
    // Delete a brew log
    private func deleteBrewLog(at offsets: IndexSet) {
        // In a real implementation, this would delete from the Kotlin ViewModel
        // For demo purposes, we'll just remove from the local array
        let logsToDelete = offsets.map { filteredAndSortedLogs[$0] }
        for log in logsToDelete {
            if let index = brewLogs.firstIndex(where: { $0.id == log.id }) {
                brewLogs.remove(at: index)
            }
        }
    }
}

// Row view for a brew log in the list
struct BrewLogRowView: View {
    let brewLog: BrewLogDisplayItem
    
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(brewLog.coffeeType)
                .font(.headline)
            
            HStack {
                Text(brewLog.brewMethod ?? "Unknown Method")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                Spacer()
                
                if let rating = brewLog.tasteRating {
                    HStack(spacing: 2) {
                        ForEach(0..<rating, id: \.self) { _ in
                            Image(systemName: "star.fill")
                                .foregroundColor(.yellow)
                                .font(.caption)
                        }
                        ForEach(0..<(5-rating), id: \.self) { _ in
                            Image(systemName: "star")
                                .foregroundColor(.gray)
                                .font(.caption)
                        }
                    }
                }
            }
            
            Text(brewLog.formattedDate)
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding(.vertical, 4)
    }
}

// Detail view for a brew log
struct BrewLogDetailView: View {
    let brewLog: MockBrewLog
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                // Header section
                VStack(alignment: .leading, spacing: 8) {
                    Text(brewLog.coffeeType)
                        .font(.largeTitle)
                        .bold()
                    
                    if let origin = brewLog.beanOrigin {
                        Text("Origin: \(origin)")
                            .font(.headline)
                            .foregroundColor(.secondary)
                    }
                    
                    if let roast = brewLog.roastLevel {
                        Text("Roast: \(roast)")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                    
                    HStack {
                        Text("Brewed on \(formatDate(brewLog.timestamp))")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        
                        Spacer()
                        
                        if let rating = brewLog.tasteRating {
                            HStack(spacing: 2) {
                                ForEach(0..<rating, id: \.self) { _ in
                                    Image(systemName: "star.fill")
                                        .foregroundColor(.yellow)
                                }
                                ForEach(0..<(5-rating), id: \.self) { _ in
                                    Image(systemName: "star")
                                        .foregroundColor(.gray)
                                }
                            }
                        }
                    }
                }
                .padding()
                .background(Color(.systemBackground))
                .cornerRadius(10)
                .shadow(radius: 1)
                
                // Brew details section
                VStack(alignment: .leading, spacing: 8) {
                    Text("Brew Details")
                        .font(.headline)
                    
                    DetailRowView(label: "Brew Method", value: brewLog.brewMethod ?? "Not specified")
                    
                    DetailRowView(label: "Coffee", value: String(format: "%.1fg", brewLog.coffeeGrams))
                    
                    DetailRowView(label: "Water", value: String(format: "%.1fg", brewLog.waterGrams))
                    
                    DetailRowView(label: "Ratio", value: "1:" + String(format: "%.1f", brewLog.ratio ?? (brewLog.waterGrams / brewLog.coffeeGrams)))
                    
                    DetailRowView(label: "Grind Setting", value: brewLog.grindSetting)
                    
                    if let temp = brewLog.waterTemperature, let unit = brewLog.temperatureUnit {
                        DetailRowView(label: "Water Temperature", value: "\(String(format: "%.1f", temp))°\(unit)")
                    }
                    
                    if let time = brewLog.brewTimeSeconds {
                        let minutes = time / 60
                        let seconds = time % 60
                        DetailRowView(label: "Brew Time", value: "\(minutes)m \(seconds)s")
                    }
                }
                .padding()
                .background(Color(.systemBackground))
                .cornerRadius(10)
                .shadow(radius: 1)
                
                // Taste notes section
                if let notes = brewLog.tasteNotes, !notes.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Taste Notes")
                            .font(.headline)
                        
                        Text(notes)
                            .font(.body)
                            .padding()
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(Color(.systemGray6))
                            .cornerRadius(8)
                    }
                    .padding()
                    .background(Color(.systemBackground))
                    .cornerRadius(10)
                    .shadow(radius: 1)
                }
                
                Spacer()
            }
            .padding()
        }
        .navigationTitle("Brew Details")
        .navigationBarTitleDisplayMode(.inline)
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
}

// Helper view for displaying a detail row
struct DetailRowView: View {
    let label: String
    let value: String
    
    var body: some View {
        HStack {
            Text(label)
                .font(.subheadline)
                .foregroundColor(.secondary)
            Spacer()
            Text(value)
                .font(.subheadline)
        }
        .padding(.vertical, 4)
    }
}

// Filter view for brew methods
struct FilterView: View {
    @Binding var selectedBrewMethod: Int?
    let brewMethods: [String]
    // For iOS 14 compatibility, using isPresented instead of Environment(\.dismiss)
    @Binding var isPresented: Bool
    
    var body: some View {
        NavigationView {
            List {
                Section(header: Text("Brew Method")) {
                    ForEach(0..<brewMethods.count, id: \.self) { index in
                        Button(action: {
                            selectedBrewMethod = index == 0 ? nil : index
                            isPresented = false
                        }) {
                            HStack {
                                Text(brewMethods[index])
                                Spacer()
                                if index == 0 && selectedBrewMethod == nil || selectedBrewMethod == index {
                                    Image(systemName: "checkmark")
                                        .foregroundColor(.blue)
                                }
                            }
                        }
                        .foregroundColor(.primary)
                    }
                }
            }
            .listStyle(InsetGroupedListStyle())
            .navigationTitle("Filter Brews")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        isPresented = false
                    }
                }
            }
        }
    }
}

// List item view for a brew log
struct BrewLogListItemView: View {
    let log: BrewLogDisplayItem
    
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(log.coffeeType)
                    .font(.headline)
                Spacer()
                Text(log.formattedDate)
                    .font(.caption)
                    .foregroundColor(.gray)
            }
            
            HStack {
                if let brewMethod = log.brewMethod {
                    Text(brewMethod)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                if let rating = log.tasteRating, rating > 0 {
                    HStack(spacing: 2) {
                        ForEach(1...5, id: \.self) { i in
                            Image(systemName: i <= rating ? "star.fill" : "star")
                                .font(.caption)
                                .foregroundColor(.yellow)
                        }
                    }
                }
            }
            
            HStack {
                Text("\(String(format: "%.1f", log.coffeeGrams))g coffee • \(String(format: "%.1f", log.waterGrams))g water • \(log.grindSetting)")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
        .padding(.vertical, 4)
    }
}

// Placeholder for the detail view
// This is a duplicate declaration and has been removed
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                // Coffee info section
                Group {
                    SectionHeaderView(title: "Coffee Information")
                    
                    DetailRowView(label: "Coffee Type", value: brewLog.coffeeType)
                    
                    if let origin = brewLog.beanOrigin {
                        DetailRowView(label: "Origin", value: origin)
                    }
                    
                    if let roastLevel = brewLog.roastLevel?.name {
                        DetailRowView(label: "Roast Level", value: roastLevel.replacingOccurrences(of: "_", with: " ").capitalized)
                    }
                }
                
                Divider()
                
                // Brewing parameters section
                Group {
                    SectionHeaderView(title: "Brewing Parameters")
                    
                    DetailRowView(label: "Coffee", value: "\(String(format: "%.1f", brewLog.coffeeGrams))g")
                    DetailRowView(label: "Water", value: "\(String(format: "%.1f", brewLog.waterGrams))g")
                    DetailRowView(label: "Ratio", value: "1:\(String(format: "%.1f", brewLog.waterGrams / brewLog.coffeeGrams))")
                    DetailRowView(label: "Grind Setting", value: brewLog.grindSetting)
                    
                    if let method = brewLog.brewMethod?.name {
                        DetailRowView(label: "Method", value: method.replacingOccurrences(of: "_", with: " ").capitalized)
                    }
                    
                    if let temp = brewLog.waterTemperature, let unit = brewLog.temperatureUnit?.name {
                        DetailRowView(label: "Water Temperature", value: "\(String(format: "%.1f", temp))°\(unit.first ?? "C")")
                    }
                    
                    if let time = brewLog.brewTimeSeconds {
                        let minutes = time / 60
                        let seconds = time % 60
                        DetailRowView(label: "Brew Time", value: "\(minutes)m \(seconds)s")
                    }
                }
                
                Divider()
                
                // Taste assessment section
                Group {
                    SectionHeaderView(title: "Taste Assessment")
                    
                    if let rating = brewLog.tasteRating {
                        HStack {
                            Text("Rating")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                            
                            Spacer()
                            
                            HStack(spacing: 4) {
                                ForEach(1...5, id: \.self) { i in
                                    Image(systemName: i <= rating ? "star.fill" : "star")
                                        .foregroundColor(.yellow)
                                }
                            }
                        }
                        .padding(.vertical, 4)
                    }
                    
                    if let notes = brewLog.tasteNotes, !notes.isEmpty {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Notes")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                            
                            Text(notes)
                                .padding()
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .background(Color(.systemGray6))
                                .cornerRadius(8)
                        }
                    }
                }
            }
            .padding()
        }
        .navigationTitle("Brew Details")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// Helper views for the detail screen
struct SectionHeaderView: View {
    let title: String
    
    var body: some View {
        Text(title)
            .font(.headline)
            .padding(.vertical, 4)
    }
}

struct DetailRowView: View {
    let label: String
    let value: String
    
    var body: some View {
        HStack {
            Text(label)
                .font(.subheadline)
                .foregroundColor(.secondary)
            Spacer()
            Text(value)
                .font(.subheadline)
        }
        .padding(.vertical, 4)
    }
}

// This duplicate declaration has been removed

// Sample data for preview
let sampleBrewLogs: [BrewLogDisplayItem] = [
    BrewLogDisplayItem(
        id: "1",
        coffeeType: "Ethiopian Yirgacheffe",
        coffeeGrams: 18.0,
        waterGrams: 300.0,
        grindSetting: "Medium-Fine (15)",
        brewMethod: "Pour Over",
        beanOrigin: "Ethiopia",
        tasteRating: 4,
        tasteNotes: "Bright acidity, floral notes with hints of citrus. Very clean finish.",
        timestamp: Date().addingTimeInterval(-86400), // Yesterday
        originalLog: BrewLog(
            logId: "1",
            timestamp: KotlinHelper.dateToInstant(Date().addingTimeInterval(-86400)),
            coffeeType: "Ethiopian Yirgacheffe",
            coffeeGrams: 18.0,
            waterGrams: 300.0,
            grindSetting: "Medium-Fine (15)",
            waterTemperature: 94.0,
            temperatureUnit: KotlinHelper.CELSIUS,
            brewMethod: KotlinHelper.POUR_OVER,
            beanOrigin: "Ethiopia",
            roastLevel: KotlinHelper.LIGHT,
            brewTimeSeconds: 180,
            tasteRating: 4,
            tasteNotes: "Bright acidity, floral notes with hints of citrus. Very clean finish.",
            photoPath: nil,
            ratio: 16.67
        )
    ),
    BrewLogDisplayItem(
        id: "2",
        coffeeType: "Colombian Supremo",
        coffeeGrams: 20.0,
        waterGrams: 320.0,
        grindSetting: "Medium (20)",
        brewMethod: "French Press",
        beanOrigin: "Colombia",
        tasteRating: 5,
        tasteNotes: "Rich body with chocolate and caramel notes. Low acidity and very smooth.",
        timestamp: Date().addingTimeInterval(-172800), // 2 days ago
        originalLog: BrewLog(
            logId: "2",
            timestamp: KotlinHelper.dateToInstant(Date().addingTimeInterval(-172800)),
            coffeeType: "Colombian Supremo",
            coffeeGrams: 20.0,
            waterGrams: 320.0,
            grindSetting: "Medium (20)",
            waterTemperature: 92.0,
            temperatureUnit: KotlinHelper.CELSIUS,
            brewMethod: KotlinHelper.FRENCH_PRESS,
            beanOrigin: "Colombia",
            roastLevel: KotlinHelper.MEDIUM,
            brewTimeSeconds: 240,
            tasteRating: 5,
            tasteNotes: "Rich body with chocolate and caramel notes. Smooth finish.",
            photoPath: nil,
            ratio: 16.0
        )
    ),
    BrewLogDisplayItem(
        id: "3",
        coffeeType: "Sumatra Mandheling",
        coffeeGrams: 16.0,
        waterGrams: 250.0,
        grindSetting: "Fine (10)",
        brewMethod: "Aeropress",
        beanOrigin: "Indonesia",
        tasteRating: 3,
        tasteNotes: "Earthy with herbal notes. A bit too bitter, might try coarser grind next time.",
        timestamp: Date().addingTimeInterval(-259200), // 3 days ago
        originalLog: BrewLog(
            logId: "3",
            timestamp: KotlinHelper.dateToInstant(Date().addingTimeInterval(-259200)),
            coffeeType: "Sumatra Mandheling",
            coffeeGrams: 16.0,
            waterGrams: 250.0,
            grindSetting: "Fine (10)",
            waterTemperature: 85.0,
            temperatureUnit: KotlinHelper.CELSIUS,
            brewMethod: KotlinHelper.AEROPRESS,
            beanOrigin: "Indonesia",
            roastLevel: KotlinHelper.DARK,
            brewTimeSeconds: 90,
            tasteRating: 3,
            tasteNotes: "Earthy with herbal notes. A bit too bitter, might try coarser grind next time.",
            photoPath: nil,
            ratio: 15.625
        )
    )
]

struct BrewLogHistoryView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            BrewLogHistoryView()
        }
    }
}

struct BrewLogRowView_Previews: PreviewProvider {
    static var previews: some View {
        let sampleLog = BrewLogDisplayItem(
            id: "1",
            coffeeType: "Ethiopian Yirgacheffe",
            coffeeGrams: 18.0,
            waterGrams: 300.0,
            grindSetting: "Medium-Fine (15)",
            brewMethod: "Pour Over",
            beanOrigin: "Ethiopia",
            tasteRating: 4,
            tasteNotes: "Bright acidity, floral notes with hints of citrus.",
            timestamp: Date(),
            originalLog: MockBrewLog(
                id: "1",
                timestamp: Date(),
                coffeeType: "Ethiopian Yirgacheffe",
                coffeeGrams: 18.0,
                waterGrams: 300.0,
                grindSetting: "Medium-Fine (15)",
                waterTemperature: 94.0,
                temperatureUnit: "C",
                brewMethod: "Pour Over",
                beanOrigin: "Ethiopia",
                roastLevel: "Light",
                brewTimeSeconds: 180,
                tasteRating: 4,
                tasteNotes: "Bright acidity, floral notes with hints of citrus.",
                photoPath: nil,
                ratio: 16.67
            )
        )
        
        return List {
            BrewLogRowView(brewLog: sampleLog)
        }
        .previewLayout(.sizeThatFits)
    }
}

struct BrewLogDetailView_Previews: PreviewProvider {
    static var previews: some View {
        let sampleLog = MockBrewLog(
            id: "1",
            timestamp: Date(),
            coffeeType: "Ethiopian Yirgacheffe",
            coffeeGrams: 18.0,
            waterGrams: 300.0,
            grindSetting: "Medium-Fine (15)",
            waterTemperature: 94.0,
            temperatureUnit: "C",
            brewMethod: "Pour Over",
            beanOrigin: "Ethiopia",
            roastLevel: "Light",
            brewTimeSeconds: 180,
            tasteRating: 4,
            tasteNotes: "Bright acidity, floral notes with hints of citrus. Very clean finish.",
            photoPath: nil,
            ratio: 16.67
        )
        
        return NavigationView {
            BrewLogDetailView(brewLog: sampleLog)
        }
    }
}
