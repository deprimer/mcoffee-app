import SwiftUI
import shared

struct NewBrewLogView: View {
    @StateObject private var viewModel = BrewLogViewModelWrapper()
    @State private var showingSuccessAlert = false
    @State private var showingRatioCalculator = false
    @State private var isShowingCamera = false
    @State private var brewImage: UIImage? = nil
    
    // Brew methods
    let brewMethods = ["Pour Over", "Aeropress", "Espresso", "French Press", "Moka Pot", "Cold Brew", "Drip", "Siphon", "Custom"]
    
    // Roast levels
    let roastLevels = ["Light", "Medium", "Medium-Dark", "Dark"]
    
    var body: some View {
        Form {
            // Essential Information Section
            Section(header: Text("Essential Information")) {
                TextField("Coffee Type/Name *", text: Binding(
                    get: { viewModel.newBrewLogState.coffeeType },
                    set: { viewModel.newBrewLogState.coffeeType = $0; viewModel.checkForSuggestions() }
                ))
                .autocapitalization(.words)
                
                HStack {
                    TextField("Coffee (g) *", text: Binding(
                        get: { viewModel.newBrewLogState.coffeeGrams > 0 ? String(format: "%.1f", viewModel.newBrewLogState.coffeeGrams) : "" },
                        set: { 
                            if let value = Double($0) {
                                viewModel.newBrewLogState.coffeeGrams = value
                            }
                        }
                    ))
                    .keyboardType(.decimalPad)
                    Spacer()
                    Text("g")
                        .foregroundColor(.gray)
                }
                
                HStack {
                    TextField("Water (g) *", text: Binding(
                        get: { viewModel.newBrewLogState.waterGrams > 0 ? String(format: "%.1f", viewModel.newBrewLogState.waterGrams) : "" },
                        set: { 
                            if let value = Double($0) {
                                viewModel.newBrewLogState.waterGrams = value
                            }
                        }
                    ))
                    .keyboardType(.decimalPad)
                    Spacer()
                    Text("g")
                        .foregroundColor(.gray)
                }
                
                // Ratio calculator button
                Button(action: {
                    showingRatioCalculator = true
                }) {
                    Label("Calculate Ratio", systemImage: "function")
                        .font(.footnote)
                }
                .sheet(isPresented: $showingRatioCalculator) {
                    RatioCalculatorView(isPresented: $showingRatioCalculator, viewModel: viewModel)
                }
                
                TextField("Grind Setting *", text: Binding(
                    get: { viewModel.newBrewLogState.grindSetting },
                    set: { viewModel.newBrewLogState.grindSetting = $0 }
                ))
                
                if let suggested = viewModel.suggestedGrindSetting {
                    HStack {
                        Image(systemName: "lightbulb.fill")
                            .foregroundColor(.yellow)
                            .font(.footnote)
                        Text("Suggested: \(suggested)")
                            .font(.footnote)
                            .foregroundColor(.blue)
                        Spacer()
                        Button("Use") {
                            viewModel.newBrewLogState.grindSetting = suggested
                        }
                        .font(.footnote)
                        .buttonStyle(.bordered)
                    }
                }
            }
            
            // Brewing Details Section
            Section(header: Text("Brewing Details")) {
                Picker("Brew Method", selection: Binding(
                    get: { viewModel.newBrewLogState.brewMethod },
                    set: { viewModel.newBrewLogState.brewMethod = $0; viewModel.checkForSuggestions() }
                )) {
                    ForEach(0..<brewMethods.count, id: \.self) { index in
                        Text(brewMethods[index])
                    }
                }
                .pickerStyle(DefaultPickerStyle())
                
                HStack {
                    TextField("Water Temperature", text: Binding(
                        get: { 
                            if let temp = viewModel.newBrewLogState.waterTemperature {
                                return String(format: "%.1f", temp)
                            }
                            return ""
                        },
                        set: { viewModel.newBrewLogState.waterTemperature = Double($0) }
                    ))
                    .keyboardType(.decimalPad)
                    
                    Picker("", selection: Binding(
                        get: { viewModel.newBrewLogState.temperatureUnit },
                        set: { viewModel.newBrewLogState.temperatureUnit = $0 }
                    )) {
                        Text("°C").tag(0)
                        Text("°F").tag(1)
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    .frame(width: 100)
                }
                
                TextField("Bean Origin", text: Binding(
                    get: { viewModel.newBrewLogState.beanOrigin },
                    set: { viewModel.newBrewLogState.beanOrigin = $0 }
                ))
                .autocapitalization(.words)
                
                Picker("Roast Level", selection: Binding(
                    get: { viewModel.newBrewLogState.roastLevel },
                    set: { viewModel.newBrewLogState.roastLevel = $0 }
                )) {
                    ForEach(0..<roastLevels.count, id: \.self) { index in
                        Text(roastLevels[index])
                    }
                }
                .pickerStyle(DefaultPickerStyle())
                
                HStack {
                    Stepper("\(viewModel.newBrewLogState.brewMinutes) min", value: Binding(
                        get: { viewModel.newBrewLogState.brewMinutes },
                        set: { viewModel.newBrewLogState.brewMinutes = $0 }
                    ), in: 0...10)
                    
                    Stepper("\(viewModel.newBrewLogState.brewSeconds) sec", value: Binding(
                        get: { viewModel.newBrewLogState.brewSeconds },
                        set: { viewModel.newBrewLogState.brewSeconds = $0 }
                    ), in: 0...59)
                }
            }
            
            // Taste Assessment Section
            Section(header: Text("Taste Assessment")) {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Rating")
                    HStack {
                        ForEach(1...5, id: \.self) { rating in
                            Image(systemName: rating <= viewModel.newBrewLogState.tasteRating ? "star.fill" : "star")
                                .foregroundColor(.yellow)
                                .font(.title2)
                                .onTapGesture {
                                    viewModel.newBrewLogState.tasteRating = rating
                                }
                        }
                    }
                }
                .padding(.vertical, 4)
                
                VStack(alignment: .leading, spacing: 8) {
                    Text("Taste Notes")
                    TextEditor(text: Binding(
                        get: { viewModel.newBrewLogState.tasteNotes },
                        set: { viewModel.newBrewLogState.tasteNotes = $0 }
                    ))
                    .frame(minHeight: 100)
                    .overlay(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(Color.gray.opacity(0.2), lineWidth: 1)
                    )
                }
                
                // Photo section
                Button(action: {
                    isShowingCamera = true
                }) {
                    Label("Add Photo", systemImage: brewImage == nil ? "camera" : "checkmark.circle")
                }
                
                if let image = brewImage {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(height: 200)
                        .cornerRadius(8)
                        .onAppear {
                            // In a real implementation, we would save the image to disk and store the path
                            // For demo purposes, we'll just set a placeholder path
                            viewModel.newBrewLogState.photoPath = "brew_photos/\(UUID().uuidString).jpg"
                        }
                }
            }
            
            // Error message section
            if let error = viewModel.error {
                Section {
                    Text(error)
                        .foregroundColor(.red)
                }
            }
            
            // Save button section
            Section {
                Button(action: {
                    saveBrewLog()
                }) {
                    Text("Save Brew Log")
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 8)
                }
                .buttonStyle(.borderedProminent)
                .disabled(isFormInvalid())
            }
        }
        .navigationTitle("New Brew")
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button("Clear") {
                    resetForm()
                }
            }
        }
        .sheet(isPresented: $isShowingCamera) {
            // Camera placeholder - in a real app, this would be a camera view
            Text("Camera would go here")
                .padding()
                .onAppear {
                    // Simulate taking a photo
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                        isShowingCamera = false
                        // In a real app, this would be the actual photo
                        brewImage = UIImage(systemName: "mug.fill")
                    }
                }
        }
        .alert(isPresented: $showingSuccessAlert) {
            Alert(
                title: Text("Success"),
                message: Text("Your brew log has been saved."),
                dismissButton: .default(Text("OK"))
            )
        }
    }
    
    private func isFormInvalid() -> Bool {
        return viewModel.newBrewLogState.coffeeType.isEmpty ||
               viewModel.newBrewLogState.coffeeGrams <= 0 ||
               viewModel.newBrewLogState.waterGrams <= 0 ||
               viewModel.newBrewLogState.grindSetting.isEmpty
    }
    
    private func saveBrewLog() {
        viewModel.saveBrewLog { success in
            if success {
                showingSuccessAlert = true
                brewImage = nil
            }
        }
    }
    
    private func resetForm() {
        viewModel.newBrewLogState = NewBrewLogFormState()
        brewImage = nil
    }
}

// Ratio Calculator View
struct RatioCalculatorView: View {
    // For iOS 14 compatibility, using isPresented instead of Environment(\.dismiss)
    @Binding var isPresented: Bool
    @ObservedObject var viewModel: BrewLogViewModelWrapper
    
    @State private var coffeeAmount: String = ""
    @State private var waterAmount: String = ""
    @State private var ratio: String = "16"
    @State private var calculationMode = 0 // 0 = calculate water, 1 = calculate coffee
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Coffee to Water Ratio")) {
                    Picker("Calculate", selection: $calculationMode) {
                        Text("Water Amount").tag(0)
                        Text("Coffee Amount").tag(1)
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    .onChange(of: calculationMode) { _ in
                        coffeeAmount = ""
                        waterAmount = ""
                    }
                    
                    HStack {
                        Text("Ratio 1:")
                        TextField("16", text: $ratio)
                            .keyboardType(.decimalPad)
                            .multilineTextAlignment(.trailing)
                    }
                    
                    if calculationMode == 0 {
                        // Calculate water based on coffee
                        HStack {
                            Text("Coffee")
                            Spacer()
                            TextField("grams", text: $coffeeAmount)
                                .keyboardType(.decimalPad)
                                .multilineTextAlignment(.trailing)
                            Text("g")
                        }
                        
                        if let coffee = Double(coffeeAmount), let ratioValue = Double(ratio), ratioValue > 0 {
                            let water = coffee * ratioValue
                            HStack {
                                Text("Water")
                                Spacer()
                                Text("\(String(format: "%.1f", water)) g")
                                    .bold()
                            }
                            
                            Button("Use These Values") {
                                viewModel.newBrewLogState.coffeeGrams = coffee
                                viewModel.newBrewLogState.waterGrams = water
                                isPresented = false
                            }
                            .buttonStyle(.borderedProminent)
                            .frame(maxWidth: .infinity)
                        }
                    } else {
                        // Calculate coffee based on water
                        HStack {
                            Text("Water")
                            Spacer()
                            TextField("grams", text: $waterAmount)
                                .keyboardType(.decimalPad)
                                .multilineTextAlignment(.trailing)
                            Text("g")
                        }
                        
                        if let water = Double(waterAmount), let ratioValue = Double(ratio), ratioValue > 0 {
                            let coffee = water / ratioValue
                            HStack {
                                Text("Coffee")
                                Spacer()
                                Text("\(String(format: "%.1f", coffee)) g")
                                    .bold()
                            }
                            
                            Button("Use These Values") {
                                viewModel.newBrewLogState.coffeeGrams = coffee
                                viewModel.newBrewLogState.waterGrams = water
                                isPresented = false
                            }
                            .buttonStyle(.borderedProminent)
                            .frame(maxWidth: .infinity)
                        }
                    }
                }
                
                Section(header: Text("Common Ratios")) {
                    Button("1:15 (Stronger)") { ratio = "15" }
                    Button("1:16 (Standard)") { ratio = "16" }
                    Button("1:17 (Lighter)") { ratio = "17" }
                }
            }
            .navigationTitle("Ratio Calculator")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        isPresented = false
                    }
                }
            }
        }
    }
}

struct NewBrewLogView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            NewBrewLogView()
        }
    }
}
