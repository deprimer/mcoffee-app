import SwiftUI

@main
struct MCoffeeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
