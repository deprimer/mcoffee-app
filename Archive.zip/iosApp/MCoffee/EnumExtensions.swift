import Foundation
import shared

// Extensions to handle Kotlin enum values in Swift
extension TemperatureUnit {
    // Fix for "Type 'TemperatureUnit' has no member 'CELSIUS'"
    static var CELSIUS: TemperatureUnit {
        return TemperatureUnit.values()[0]
    }
    
    static var FAHRENHEIT: TemperatureUnit {
        return TemperatureUnit.values()[1]
    }
}

extension BrewMethod {
    // Fix for "Type 'BrewMethod' has no member 'POUR_OVER'"
    static var POUR_OVER: BrewMethod {
        return BrewMethod.values()[0]
    }
    
    static var AEROPRESS: BrewMethod {
        return BrewMethod.values()[1]
    }
    
    static var ESPRESSO: BrewMethod {
        return BrewMethod.values()[2]
    }
    
    static var FRENCH_PRESS: BrewMethod {
        return BrewMethod.values()[3]
    }
    
    static var MOKA_POT: BrewMethod {
        return BrewMethod.values()[4]
    }
    
    static var COLD_BREW: BrewMethod {
        return BrewMethod.values()[5]
    }
    
    static var DRIP: BrewMethod {
        return BrewMethod.values()[6]
    }
    
    static var SIPHON: BrewMethod {
        return BrewMethod.values()[7]
    }
    
    static var CUSTOM: BrewMethod {
        return BrewMethod.values()[8]
    }
}

extension RoastLevel {
    // Fix for "Type 'RoastLevel' has no member 'LIGHT'"
    static var LIGHT: RoastLevel {
        return RoastLevel.values()[0]
    }
    
    static var MEDIUM: RoastLevel {
        return RoastLevel.values()[1]
    }
    
    static var MEDIUM_DARK: RoastLevel {
        return RoastLevel.values()[2]
    }
    
    static var DARK: RoastLevel {
        return RoastLevel.values()[3]
    }
}
