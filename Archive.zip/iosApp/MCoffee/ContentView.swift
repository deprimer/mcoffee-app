import SwiftUI
import shared

struct ContentView: View {
    @State private var selectedTab = 0
    
    var body: some View {
        TabView(selection: $selectedTab) {
            // Log Entry Tab
            NavigationView {
                NewBrewLogView()
                    .navigationTitle("New Brew")
            }
            .tabItem {
                Label("New Brew", systemImage: "plus.circle")
            }
            .tag(0)
            
            // History Tab
            NavigationView {
                BrewLogHistoryView()
                    .navigationTitle("History")
            }
            .tabItem {
                Label("History", systemImage: "list.bullet")
            }
            .tag(1)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
